Task 6:
The starting global position of the robot is as follows:
x = 15.8 cm
y = 50 cm
heading \phi = 90 degree
The car has completed 2 cycles.
