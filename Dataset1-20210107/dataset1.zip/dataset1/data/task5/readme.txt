Task 5:
The global position of the robot is as follows:
x = 60 cm
y = 39 cm
heading \phi = 90 degree

The detected QR-codes are on WALL 1:
32, 31, 27, 26, 25, 21, 20

The global distance of these QR-codes from WALL 4 can be found in Walls.html file.


