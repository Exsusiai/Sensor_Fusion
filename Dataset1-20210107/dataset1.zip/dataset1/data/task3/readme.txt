For task 3, use the file camera_module_calibration_task3.csv
There are two columns in the csv file.
- First column is the distance between the QR code and the robot camera. 
- Second column is the height of qr code detected by the camera.
In order to get the true distance between the QR code and the robot camera, you need to add the following distances:
- Distance of camera pinhole and the IR detector = 1.6 cm
- Distance of the wall and the wooden list = 5cm

You can also check camera_reading.csv to understand the data.
