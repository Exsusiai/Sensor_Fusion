For task 4, use the file robot_speed_task4.csv
There are two columns in the csv file.
- First column is the distance (cm) that the robot moved forward. 
- Second column is the time lapse (s) that the robot moved at each 40 cm interval.

You can also check motor_control_reading.csv to understand the data.
