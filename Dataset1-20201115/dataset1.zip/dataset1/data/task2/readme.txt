In task 2, the measurements/reading has been recorded in each direction/axis in the following order:
+z axis, -z axis, +x axis, -x axis, +y axis, -y axis.

